<?php

class Database {

    private $host = "localhost:8889";
    private $username = "root";
    private $password = "root";
    private $database = "efficom_airbnb";

    public $conn;

    public function getConnection(){

        $this->conn = null;

        try{
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->database, $this->username, $this->password);
            $this->conn->exec("set names utf8");
        }catch(PDOException $exception){
            echo "Error: " . $exception->getMessage();
        }

        return $this->conn;
    }
}
?>